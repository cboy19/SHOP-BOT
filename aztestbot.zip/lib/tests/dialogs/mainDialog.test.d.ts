/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 
import { TextPrompt } from 'botbuilder-dialogs';
import { DialogTestClient, DialogTestLogger } from 'botbuilder-testing';
import { BookingDialog } from '../../dialogs/bookingDialog';
import { FlightBookingRecognizer } from '../../dialogs/flightBookingRecognizer';
import { MainDialog } from '../../dialogs/mainDialog';
const assert = require('assert');
*/
/**
 * A mock FlightBookingRecognizer for our main dialog tests that takes
 * a mock luis result and can set as isConfigured === false.
 
class MockFlightBookingRecognizer extends FlightBookingRecognizer {
    private isLuisConfigured: boolean;
    constructor(isConfigured, private mockResult?: any) {
        super(isConfigured);
        this.isLuisConfigured = isConfigured;
        this.mockResult = mockResult;
    }

    public async executeLuisQuery(context) {
        return this.mockResult;
    }

    get isConfigured() {
        return (this.isLuisConfigured);
    }
}
*/
/**
 * A simple mock for Booking dialog that just returns a preset booking info for tests.

class MockBookingDialog extends BookingDialog {
    constructor() {
        super('bookingDialog');
    }

    public async beginDialog(dc, options) {
        const bookingDetails = {
            destination: 'Seattle',
            origin: 'New York',
            travelDate: '2025-07-08'
        };
        await dc.context.sendActivity(`${ this.id } mock invoked`);
        return await dc.endDialog(bookingDetails);
    }
}
 */
/**
 * A specialized mock for BookingDialog that displays a dummy TextPrompt.
 * The dummy prompt is used to prevent the MainDialog waterfall from moving to the next step
 * and assert that the main dialog was called.
 
class MockBookingDialogWithPrompt extends BookingDialog {
    constructor() {
        super('bookingDialog');
    }

    public async beginDialog(dc, options) {
        dc.dialogs.add(new TextPrompt('MockDialog'));
        return await dc.prompt('MockDialog', { prompt: `${ this.id } mock invoked` });
    }
}
*/
