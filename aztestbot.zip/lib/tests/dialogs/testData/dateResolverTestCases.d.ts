/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
declare const now: Date;
declare const tomorrow: string;
declare const dayAfterTomorrow: string;
declare function formatDate(date: any): string;
