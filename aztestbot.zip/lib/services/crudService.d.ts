import { Items } from '../cards/types';
import { Cart } from '../cart/cart';
export declare function searchItems(searchTerm: String): Promise<Items[]>;
export declare function createCart(cart: Cart): Promise<String>;
