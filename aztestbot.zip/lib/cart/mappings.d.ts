import { Cart } from './cart';
import { Items } from '../cards/types';
export declare function searchMappings(searchItems: any): Items[];
export declare function submitMapping(cart: Cart): String;
