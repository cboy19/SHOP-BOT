import { Items, Carts } from "../cards/types";
export declare class Cart {
    private cart;
    private initial;
    private static index;
    addItem(item: Items): void;
    deleteItem(ind: String): void;
    getcalculateTotal(): number;
    clear(): void;
    getCart(): Carts[];
    getCount(): number;
    updateCart(value: any): void;
}
