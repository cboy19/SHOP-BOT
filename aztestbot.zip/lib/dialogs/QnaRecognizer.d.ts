import { TurnContext } from 'botbuilder';
import { QnAMakerResult } from 'botbuilder-ai';
export declare class QnaRecognizer {
    private recognizer;
    constructor(config: any);
    readonly isConfigured: boolean;
    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {TurnContext} context
     */
    executeQnaQuery(context: TurnContext): Promise<QnAMakerResult[]>;
}
