import { ComponentDialog } from 'botbuilder-dialogs';
export declare class CreatecartDialog extends ComponentDialog {
    constructor(id: string);
    private viewcartStep;
}
