import { ComponentDialog } from 'botbuilder-dialogs';
export declare class MyreqsDialog extends ComponentDialog {
    constructor(id: string);
    private requestStep;
}
