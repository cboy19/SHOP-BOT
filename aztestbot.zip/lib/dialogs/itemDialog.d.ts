import { ComponentDialog } from 'botbuilder-dialogs';
export declare class ItemDialog extends ComponentDialog {
    constructor(id: string);
    private addItem;
}
