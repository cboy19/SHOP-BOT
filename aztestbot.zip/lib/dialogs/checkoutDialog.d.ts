import { ComponentDialog } from 'botbuilder-dialogs';
export declare class CheckoutDialog extends ComponentDialog {
    constructor(id: string);
    private checkoutStep;
}
