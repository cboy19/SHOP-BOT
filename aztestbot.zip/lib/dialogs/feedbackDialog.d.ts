import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class FeedbackDialog extends CancelAndHelpDialog {
    constructor(id: string);
    private feedbacktermStep;
    private confirmStep;
    private updateStep;
    private savefeedback;
}
