import { StatePropertyAccessor, TurnContext } from 'botbuilder';
import { ComponentDialog, DialogState } from 'botbuilder-dialogs';
import { SearchDialog } from './searchDialog';
import { ItemDialog } from './itemDialog';
import { CreatecartDialog } from './createcartDialog';
import { CheckoutDialog } from './checkoutDialog';
import { DeleteDialog } from './deleteDialog';
import { MyreqsDialog } from './myreqsDialog';
import { FeedbackDialog } from './feedbackDialog';
import { QnaRecognizer } from './QnaRecognizer';
import { LuisappRecognizer } from './luisappRecognizer';
export declare class MainDialog extends ComponentDialog {
    private luisRecognizer;
    private qnaRecognizer;
    private cart;
    private searchTerm;
    constructor(luisRecognizer: LuisappRecognizer, qnaRecognizer: QnaRecognizer, searchDialog: SearchDialog, itemDialog: ItemDialog, createcartDialog: CreatecartDialog, checkoutDialog: CheckoutDialog, deleteDialog: DeleteDialog, myreqsDialog: MyreqsDialog, feedbackDialog: FeedbackDialog);
    /**
     * The run method handles the incoming activity (in the form of a DialogContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {TurnContext} context
     */
    run(context: TurnContext, accessor: StatePropertyAccessor<DialogState>): Promise<void>;
    private initialStep;
    private finalStep;
}
