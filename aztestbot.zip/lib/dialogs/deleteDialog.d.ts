import { ComponentDialog } from 'botbuilder-dialogs';
export declare class DeleteDialog extends ComponentDialog {
    constructor(id: string);
    private deleteStep;
}
