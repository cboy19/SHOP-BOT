import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class SearchDialog extends CancelAndHelpDialog {
    constructor(id: string);
    private searchtermStep;
    private confirmStep;
    private searchStep;
}
