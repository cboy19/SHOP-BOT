import { ComponentDialog, DialogContext, DialogTurnResult } from 'botbuilder-dialogs';
export declare class CancelAndHelpDialog extends ComponentDialog {
    constructor(id: string);
    onContinueDialog(innerDc: DialogContext): Promise<DialogTurnResult>;
    private interrupt;
}
