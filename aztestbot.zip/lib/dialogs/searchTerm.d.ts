export declare class SearchTerm {
    term: String;
    feedback: String;
}
