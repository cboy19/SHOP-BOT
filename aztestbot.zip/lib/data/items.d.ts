export declare let items: {
    "description": string;
    "supplierpartId": string;
    "imgUrl": string;
    "price": string;
    "currency": string;
    "quantity": string;
    "uom": string;
    "supplier": string;
    "subtotal": string;
}[];
