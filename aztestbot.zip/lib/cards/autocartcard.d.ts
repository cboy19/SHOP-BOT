import { Attachment } from "botbuilder";
import { Carts } from "./types";
export declare function createAutoCartcard(data: Carts[], cardType: String, total: number): Attachment;
