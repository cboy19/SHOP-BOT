import { Activity, Attachment } from "botbuilder";
import { Items } from "./types";
export declare function createCarosule(data: Items[]): Partial<Activity>;
export declare function createList(data: Items[]): Partial<Activity>;
export declare function createItemCard(data: Items): Attachment;
export declare function createWelcomeCard(): Attachment;
export declare function createSearchingCard(): Attachment;
export declare function viewCart(): Attachment;
export declare function displayPR(data: any): Attachment;
