export interface Items {
    description: String;
    supplierpartId: String;
    imgUrl: String;
    price: Number;
    currency: String;
    quantity: String;
    uom: String;
    supplier: Number;
    mcccode: Number;
    auxiliary: String;
    subtotal: String;
    key: String;
}
export interface Carts {
    key: String;
    index: String;
    description: String;
    supplierpartId: String;
    imgUrl: String;
    price: String;
    currency: String;
    quantity: String;
    uom: String;
    supplier: Number;
    mcccode: Number;
    auxiliary: String;
    subtotal: String;
}
export interface Requisition {
    aribapr: String;
    eccpr: String;
    date: Date;
}
export declare enum BUTTON_TEXT {
    create = "&createpr",
    list = "&list",
    feedback = "&feedback",
    viewcaret = "&viewCart",
    checkout = "&checkout",
    cancel = "&cancel",
    order = "&order"
}
export declare var Cartcard: {
    "$schema": string;
    "version": string;
    "type": string;
    "body": ({
        "type": string;
        "text": string;
        "weight": string;
        "horizontalAlignment": string;
        "size": string;
        "id": string;
        "color": string;
        "items"?: undefined;
        "style"?: undefined;
        "columns"?: undefined;
    } | {
        "type": string;
        "items": any[];
        "id": string;
        "style": string;
        "text"?: undefined;
        "weight"?: undefined;
        "horizontalAlignment"?: undefined;
        "size"?: undefined;
        "color"?: undefined;
        "columns"?: undefined;
    } | {
        "type": string;
        "id": string;
        "columns": ({
            "type": string;
            "width": number;
            "id": string;
            "items": {
                "type": string;
                "text": string;
                "size": string;
                "isSubtle": boolean;
                "weight": string;
                "id": string;
                "color": string;
            }[];
            "horizontalAlignment"?: undefined;
            "verticalContentAlignment"?: undefined;
            "style"?: undefined;
        } | {
            "type": string;
            "width": number;
            "items": {
                "type": string;
                "text": string;
                "size": string;
                "id": string;
                "horizontalAlignment": string;
                "weight": string;
                "color": string;
            }[];
            "id": string;
            "horizontalAlignment"?: undefined;
            "verticalContentAlignment"?: undefined;
            "style"?: undefined;
        } | {
            "type": string;
            "width": string;
            "items": {
                "type": string;
                "text": string;
                "id": string;
                "color": string;
                "horizontalAlignment": string;
            }[];
            "id": string;
            "horizontalAlignment": string;
            "verticalContentAlignment": string;
            "style": string;
        })[];
        "text"?: undefined;
        "weight"?: undefined;
        "horizontalAlignment"?: undefined;
        "size"?: undefined;
        "color"?: undefined;
        "items"?: undefined;
        "style"?: undefined;
    })[];
    "id": string;
};
export declare var Item: {
    "type": string;
    "items": ({
        "type": string;
        "text": string;
        "weight": string;
        "spacing": string;
        "id": string;
        "wrap": boolean;
        "separator"?: undefined;
        "columns"?: undefined;
    } | {
        "type": string;
        "text": string;
        "weight": string;
        "spacing": string;
        "id": string;
        "wrap"?: undefined;
        "separator"?: undefined;
        "columns"?: undefined;
    } | {
        "type": string;
        "separator": boolean;
        "columns": ({
            "type": string;
            "width": number;
            "items": ({
                "type": string;
                "text": string;
                "id": string;
                "altText"?: undefined;
            } | {
                "type": string;
                "altText": string;
                "id": string;
                "text"?: undefined;
            })[];
            "id": string;
        } | {
            "type": string;
            "width": number;
            "items": ({
                "type": string;
                "id": string;
                "columns": ({
                    "type": string;
                    "width": string;
                    "items": {
                        "type": string;
                        "text": string;
                        "id": string;
                    }[];
                    "id": string;
                } | {
                    "type": string;
                    "width": number;
                    "items": {
                        "type": string;
                        "text": string;
                        "id": string;
                    }[];
                    "id": string;
                } | {
                    "type": string;
                    "width": string;
                    "id": string;
                    "items": {
                        "type": string;
                        "altText": string;
                        "id": string;
                        "url": string;
                        "spacing": string;
                        "horizontalAlignment": string;
                        "size": string;
                        "width": string;
                    }[];
                })[];
            } | {
                "type": string;
                "id": string;
                "columns": ({
                    "type": string;
                    "width": number;
                    "items": {
                        "type": string;
                        "size": string;
                        "text": string;
                        "horizontalAlignment": string;
                        "spacing": string;
                        "id": string;
                    }[];
                    "id": string;
                } | {
                    "type": string;
                    "width": string;
                    "id": string;
                    "items": {
                        "type": string;
                        "text": string;
                        "id": string;
                    }[];
                })[];
            } | {
                "type": string;
                "id": string;
                "columns": ({
                    "type": string;
                    "width": number;
                    "id": string;
                    "items": {
                        "type": string;
                        "placeholder": string;
                        "id": string;
                        "value": string;
                        "min": number;
                        "max": number;
                    }[];
                } | {
                    "type": string;
                    "width": string;
                    "id": string;
                    "items": {
                        "type": string;
                        "text": string;
                        "id": string;
                        "size": string;
                    }[];
                })[];
            })[];
            "id": string;
        })[];
        "id": string;
        "text"?: undefined;
        "weight"?: undefined;
        "spacing"?: undefined;
        "wrap"?: undefined;
    } | {
        "type": string;
        "spacing": string;
        "columns": ({
            "type": string;
            "width": number;
            "items": {
                "type": string;
                "text": string;
                "size": string;
                "id": string;
                "weight": string;
            }[];
            "id": string;
        } | {
            "type": string;
            "width": number;
            "items": {
                "type": string;
                "horizontalAlignment": string;
                "text": string;
                "size": string;
                "weight": string;
                "id": string;
                "color": string;
            }[];
            "id": string;
        } | {
            "type": string;
            "width": string;
            "id": string;
            "items": {
                "type": string;
                "text": string;
                "id": string;
                "color": string;
            }[];
        })[];
        "id": string;
        "text"?: undefined;
        "weight"?: undefined;
        "wrap"?: undefined;
        "separator"?: undefined;
    })[];
    "id": string;
    "style": string;
    "backgroundImage": string;
};
