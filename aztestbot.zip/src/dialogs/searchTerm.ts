

export class SearchTerm {
    public term: String;
    public feedback: String;
}