
export let items = [{
    "description": "Mini Trays with aluminium base",
    "supplierpartId": "123456",
    "imgUrl":"/Users/ips/Downloads/images/small.jpeg",
    "price": "10",
    "currency": "USD",
    "quantity": "0",
    "uom": "EA",
    "supplier": "100045678",
    "subtotal": ""
 },
 {
    "description": "Medium Trays with aluminium base",
    "supplierpartId": "345678",
    "imgUrl":"/Users/ips/Downloads/images/Medium.jpg",
    "price": "15",
    "currency": "USD",
    "quantity": "0",
    "uom": "EA",
    "supplier": "100076547",
    "subtotal": ""
 },
 {
    "description": "Large Trays with aluminium base",
    "supplierpartId": "967859",
    "imgUrl":"/Users/ips/Downloads/images/large.jpeg",
    "price": "20",
    "currency": "USD",
    "quantity": "0",
    "uom": "EA",
    "supplier": "100090067",
    "subtotal": ""  
 }]
